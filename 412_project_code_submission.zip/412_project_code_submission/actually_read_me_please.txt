Directions for use:

To generate the figures present in the final report, do the following:

Make sure all the functions are included in the same file location
Make sure you do not have any previously generated figure pdfs open in Adobe Acrobat/Reader, as this will cause an error.
Run "finaltest.m"

I know it works in MATLAB R2020a, it will probably work in older releases, and may work in Octave yet I have not tried that.

that's it!

note that the iterated loop may not always converge, if errors appear try decreasing the number of iterations or the number of panels