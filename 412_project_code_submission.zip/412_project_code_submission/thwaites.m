function [theta, deltastar, Cf, tau, lambda] = thwaites(coords, ue, mu, nu)
%thwaites Summary of this function goes here
%   Detailed explanation goes here

%% geometry discretization
% surface panel edges
X = coords(1,:);
Y = coords(2,:);

N = length(X)-1;

% control points
Xc = X(1:N) + diff(X)/2;
Yc = Y(1:N) + diff(Y)/2;

% arc lengths (from start at control points)
ds = sqrt(diff(X).^2 + diff(Y).^2);

% arc length coordinate
S = cumsum([0,ds]);
length(S);
length(ue);

%% compute theta
theta = sqrt( (0.45*nu)./(ue.^6) .* cumtrapz(S, (ue.^5)));

%% compute lambda
lambda = (theta.^2)/nu .* gradient(ue, S);

lambdaMin = -0.09;

% for i = 1:length(lambda)
%     if lambda(i) < lambdaMin
%         lambda(i) = NaN;
%     end
% end

%% f(lambda), g(lambda)

fFun = @(lambda) 0.5*(2 + 4.14*(0.25-lambda) - 83.5*(0.25-lambda).^2 ...
    + 854*(0.25-lambda).^3 - 3337*(0.25-lambda).^4 + 4576*(0.25-lambda).^5);
gFun = @(lambda) 0.5*((lambda + 0.09).^0.62);

f = fFun(lambda);
g = gFun(lambda);

%% deltastar, Cf, tau

deltastar = theta.*f;

H = deltastar./theta;

duedx = gradient(ue,S);
dthdx = gradient(theta,S);

Cf = 2*(dthdx + (2+H).*(theta./ue).*duedx);

tau = (mu*ue)./theta .*g;

%% example
% flip x and y because we want to go from the stagnation point to the TE
% take the negative of Vt as ue because we're on the lower surface
% thwaites([fliplr(Xc(1:stagind)); fliplr(Yc(1:stagind))], fliplr(-Vt(1:stagind)), 0.0001)

end

