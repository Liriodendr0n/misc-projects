function [theta, deltastar, H] = heads(coords, ue, theta0, H0, mu, nu)
%heads Summary of this function goes here
%   Detailed explanation goes here

%% geometry discretization
% surface panel edges
X = coords(1,:);
Y = coords(2,:);

N = length(X)-1;

% control points
Xc = X(1:N) + diff(X)/2;
Yc = Y(1:N) + diff(Y)/2;

% arc lengths (from start at control points)
ds = sqrt(diff(X).^2 + diff(Y).^2);

% arc length coordinate
S = cumsum([0,ds]);
%length(S)
%length(ue)

%% define functions
cf = @(H, theta, ue) 0.246/(10^(0.678*H) * (ue*theta/nu)^0.268);
F = @(H1) 0.0306/((H1-3)^0.6169);
G = @(H) 3.0445 + 0.8702/((H-1.1)^1.7271);
Gprime = @(H) -1.0983*(H-1.1)^(-2.2621);

%% prepare derivatives
duedx = gradient(ue, S);

%% do numerical integration
H(1) = H0;
theta(1) = theta0;
for i = 1:length(S)-1

    % if H > 2.4, don't grow BL (it's separated)
    if H(i) > 2.4
        dthdx(i) = dthdx(i-1);
        dHdx(i) = dHdx(i-1);
    else
        % calculate differentials
        dthdx(i) = cf(H(i),theta(i),ue(i))/2 - (2+H(i))*(theta(i)/ue(i))*duedx(i);

        dHdx(i) = 1/(Gprime(H(i))*ue(i)*theta(i)) * ( ue(i)*F(G(H(i))) - ...
            duedx(i)*theta(i)*G(H(i)) - dthdx(i)*ue(i)*G(H(i)) );
    end
    
    theta(i+1) = theta(i) + dthdx(i)*ds(i);
    H(i+1) = H(i) + dHdx(i)*ds(i);
    Cf(i) = cf(H(i), theta(i), ue(i));
    
end

%% process results

deltastar = H.*theta;

end

