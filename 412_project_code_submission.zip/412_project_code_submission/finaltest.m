clear
close all
clc

set(groot,'defaultAxesTickLabelInterpreter','latex');
set(groot,'defaulttextinterpreter','latex');
set(groot,'defaultLegendInterpreter','latex');

%% set flight conditions
alpha = linspace(-5, 15, 21);

alpharad = deg2rad(alpha);
Re = 100000;

%% create geometry
N = 101;

NACAcode = [2, 4, 12];
[x, y] = genNACA4(NACAcode, 1, N);
coords = [x; y];
xc = x(1:end-1) + diff(x)./2;
yc = y(1:end-1) + diff(y)./2;
s = cumsum(sqrt(diff(x).^2 + diff(y).^2));

iter = 4;

%% loop over flight conditions
for a = 1:length(alpharad)

    [cpi, cpv, cf, deltastar, theta] = CpCf(coords, Re, alpharad(a), iter);

    [Cni, Cai] = CnCa(coords, cpi, cf, 'inviscid');
    Cli(a) = Cni.*cos(alpharad(a)) - Cai.*sin(alpharad(a));
    Cdi(a) = Cni.*sin(alpharad(a)) + Cai.*cos(alpharad(a));

    [Cnv, Cav] = CnCa(coords, cpv, cf, 'viscous');
    Clv(a) = Cnv.*cos(alpharad(a)) - Cav.*sin(alpharad(a));
    Cdv(a) = Cnv.*sin(alpharad(a)) + Cav.*cos(alpharad(a));
    
    Deltastar(:,a) = deltastar';
    Theta(:,a) = theta';
    Cpi(:,a) = cpi';
    Cpv(:,a) = cpv';
    Cf(:,a) = cf';
    
    
end

%% local plots
plotind = 11;
[~, stagind] = max(Cpv(:,plotind));
figure('name', 'BLvis', 'units', 'inches', 'papersize', [7 2], 'paperposition', [0 0 7 2])
hold on
grid on

plotx = x.*cosd(alpha(plotind)) + y.*sind(alpha(plotind));
ploty = -x.*sind(alpha(plotind)) + y.*cosd(alpha(plotind));
plot(plotx, ploty, 'color', 'black', 'linestyle', '-')

[deltacoords] = surfDisp(coords, Deltastar(:,plotind)');
deltaplotx = deltacoords(1,:).*cosd(alpha(plotind)) + deltacoords(2,:).*sind(alpha(plotind));
deltaploty = -deltacoords(1,:).*sind(alpha(plotind)) + deltacoords(2,:).*cosd(alpha(plotind));
plot(deltaplotx, deltaploty, 'color', 'black', 'linestyle', '--')

[thetacoords] = surfDisp(coords, Theta(:,plotind)');
thetaplotx = thetacoords(1,:).*cosd(alpha(plotind)) + thetacoords(2,:).*sind(alpha(plotind));
thetaploty = -thetacoords(1,:).*sind(alpha(plotind)) + thetacoords(2,:).*cosd(alpha(plotind));

plot(thetaplotx, thetaploty, 'color', 'black', 'linestyle', '-.')
scatter(plotx(stagind), ploty(stagind), [15], 'black', 'filled')
axis equal
xlim([-0.1, 1.1])
ylim([-0.15, 0.1])

legend('Surface', '$\delta ^\star$(s)', '$\theta$(s)', 'location', 'northeast')
title("NACA " + NACAcode(1) + NACAcode(2) + NACAcode(3) + ":  Re = " + Re + ", $\alpha$ = " + alpha(plotind) + "$^\circ$")

print('figures\BLvis.pdf', '-dpdf', '-painters')

%
figure('name', 'Cp', 'units', 'inches', 'papersize', [3 3], 'paperposition', [0 0 3 3])
hold on
grid on
grid minor
plot(xc, Cpi(:,plotind))
plot(xc, Cpv(:,plotind))
set(gca, 'Ydir', 'reverse')
xlim([0, 1])
ylabel('Pressure Coefficient')
xlabel('Chord Position')
title("NACA " + NACAcode(1) + NACAcode(2) + NACAcode(3) + ":  Re = " + Re + ", $\alpha$ = " + alpha(plotind) + "$^\circ$")
legend('Inviscid', 'Viscous', 'location', 'best')

print('figures\Cp.pdf', '-dpdf', '-painters')

%
figure('name', 'Cf', 'units', 'inches', 'papersize', [3 3], 'paperposition', [0 0 3 3])
hold on
grid on
grid minor
plot(s, abs(Cf(:,plotind).*(ones(N-1,1)-Cpi(:,plotind))))
plot(s, abs(Cf(:,plotind).*(ones(N-1,1)-Cpv(:,plotind))))
xlim([0, s(end)])
ylim([0, 0.1])
ylabel('Skin Friction Coefficient')
xlabel('Arc-Length Position')
title("NACA " + NACAcode(1) + NACAcode(2) + NACAcode(3) + ":  Re = " + Re + ", $\alpha$ = " + alpha(plotind) + "$^\circ$")
legend('Inviscid Cp', 'Viscous Cp', 'location', 'best')

print('figures\Cf.pdf', '-dpdf', '-painters')

%
figure('name', 'BLthickness', 'units', 'inches', 'papersize', [3 3], 'paperposition', [0 0 3 3])
sgtitle("NACA " + NACAcode(1) + NACAcode(2) + NACAcode(3) + ":  Re = " + Re + ", $\alpha$ = " + alpha(plotind) + "$^\circ$")
subplot(2, 1, 1)
hold on
grid on
grid minor
plot(xc, Deltastar(:,plotind), 'color', [0.8500 0.3250 0.0980])
xlim([0, 1])
ylim([0, 0.035])
ylabel('$\delta^\star$')

subplot(2, 1, 2)
hold on
grid on
grid minor
plot(xc, Theta(:,plotind), 'color', [0.8500 0.3250 0.0980])
xlim([0, 1])
ylim([0, 0.035])
ylabel('$\theta$')
xlabel('Chord Position')

print('figures\BLthick.pdf', '-dpdf', '-painters')

%
figure('name', 'H', 'units', 'inches', 'papersize', [3 3], 'paperposition', [0 0 3 3])
hold on
grid on
grid minor
plot(xc, Deltastar(:,plotind)./Theta(:,plotind), 'color', [0.8500 0.3250 0.0980])
xlim([0, 1])
ylim([0, 3.5])
ylabel('Shape Factor $\delta^\star/\theta$')
xlabel('Chord Position')
title("NACA " + NACAcode(1) + NACAcode(2) + NACAcode(3) + ":  Re = " + Re + ", $\alpha$ = " + alpha(plotind) + "$^\circ$")

print('figures\H.pdf', '-dpdf', '-painters')

%% global plots
figure('name', 'ClCd', 'units', 'inches', 'papersize', [3 3], 'paperposition', [0 0 3 3])
hold on
grid on
grid minor
scatter(alpha, Cli./Cdv, 'filled')
scatter(alpha, Clv./Cdv, 'filled')
ylim([-100, 100])
xlim([min(alpha) max(alpha)])
xlabel('Angle of Attack')
ylabel('Lift/Drag Ratio')
legend('Inviscid Lift', 'Viscous Lift', 'location', 'best')
title("NACA " + NACAcode(1) + NACAcode(2) + NACAcode(3) + ":  Re = " + Re)

print('figures\ClCd.pdf', '-dpdf', '-painters')

%
figure('name', 'Cla', 'units', 'inches', 'papersize', [3 3], 'paperposition', [0 0 3 3])
hold on
grid on
grid minor
scatter(alpha, Cli, 'filled')
scatter(alpha, Clv, 'filled')
xlim([min(alpha) max(alpha)])
xlabel('Angle of Attack')
ylabel('Lift Coefficient')
legend('Inviscid Lift', 'Viscous Lift', 'location', 'best')
title("NACA " + NACAcode(1) + NACAcode(2) + NACAcode(3) + ":  Re = " + Re)

print('figures\Cla.pdf', '-dpdf', '-painters')

%
figure('name', 'Cda', 'units', 'inches', 'papersize', [3 3], 'paperposition', [0 0 3 3])
hold on
grid on
grid minor
scatter(alpha, Cdv, [], [0.8500 0.3250 0.0980], 'filled')
xlim([min(alpha) max(alpha)])
xlabel('Angle of Attack')
ylabel('Drag Coefficient')
legend('Viscous Drag', 'location', 'best')
title("NACA " + NACAcode(1) + NACAcode(2) + NACAcode(3) + ":  Re = " + Re)

print('figures\Cda.pdf', '-dpdf', '-painters')

%
figure('name', 'CdCl', 'units', 'inches', 'papersize', [3 3], 'paperposition', [0 0 3 3])
hold on
grid on
grid minor
scatter(Cdv, Cli, 'filled')
scatter(Cdv, Clv, 'filled')

xlim([0, 0.05])
xlabel('Drag Coefficient')
ylabel('Lift Coefficient')
legend('Inviscid Lift', 'Viscous Lift', 'location', 'best')
title("NACA " + NACAcode(1) + NACAcode(2) + NACAcode(3) + ":  Re = " + Re)

print('figures\CdCl.pdf', '-dpdf', '-painters')
