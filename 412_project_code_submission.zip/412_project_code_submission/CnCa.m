function [Cn, Ca] = CnCa(coords, Cp, Cf, mode)
%ClCd Calculates normal and axial force coefficients from Cp, Cf, and geometry
%   Detailed explanation goes here

x = coords(1,:);
y = coords(2,:);
dx = diff(x);
dy = diff(y);
theta = atan2(dy, dx);

% inviscid components
Cni = sum(dx.* -Cp);
Cai = sum(dy.* Cp);

% viscous components
Cnv = sum(dx.* Cf.*(1-Cp));
Cav = sum(dy.* Cf.*(1-Cp));

% sum

if mode == "viscous"
    Cn = Cni + Cnv;
    Ca = Cai + Cav;
elseif mode == "inviscid"
    Cn = Cni;
    Ca = Cai;
end




end

