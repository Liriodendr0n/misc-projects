function [stagPointInd] = stagpoint(Vt)
%stagpoint Finds the stagnation point, and returns the "splitting index"
%   Lower surface run = 1:stagPointInd
%   Upper surface run = stagPointInd+1:N


[~, stagPointInd] = max(Vt-(10*max(Vt))*(1/2 + sign(Vt)/2));


end

