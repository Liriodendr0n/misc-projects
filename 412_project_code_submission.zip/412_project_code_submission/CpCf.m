function [Cpi, Cpv, Cf, deltastar, theta, stagind] = CpCf(coords, Re, alpha, maxIter)
%CpCf calculates the inviscid and viscous Cp, and Cf
%   Detailed explanation goes here

%% 1: flight condition
alpha;
rho = 1;
mu = 1;
nu = mu/rho;
chord = 1;
Vinf = Re*mu./(rho*chord);

%% 2: geometry preparation
% surface panel edges
X = coords(1,:);
Y = coords(2,:);

N = length(X)-1;

% control points
Xc = X(1:N) + diff(X)/2;
Yc = Y(1:N) + diff(Y)/2;

% arc lengths (from start at control points)
ds = sqrt(diff(X).^2 + diff(Y).^2);

% arc length coordinate
S = cumsum([ds]);

%% 3: inviscid calculation
geoCoords = coords;
[~, ~, ~, Cpi] = panelHS(geoCoords, Vinf, alpha);

%% 4: iterated loop (viscous calculation)
iter = 1;

coords = geoCoords;

while iter <= maxIter
    %% 4a: get panel method coordinates
    coords;
    %% 4b: do panel method
    [~, ~, Vt, Cp] = panelHS(coords, Vinf, alpha);
    %% 4c: find the stagnation point
    stagind = stagpoint(Vt);
    stagind = stagind+1;
    %% 4d: find the minimum pressure points (forced transition)
    [~, TrindL] = min(Vt);
    
    [~, TrindU] = max(Vt);
    %% 4d: calculate delta* 
    % BL transition is not the focus of this project, transition is forced
    % at Cp_min (equivalent to ue_max)
        %% 4di:   laminar region
        [LamthetaL, LamdeltastarL] = thwaites(fliplr(coords(:,TrindL:stagind-1)), fliplr(-Vt(TrindL:stagind-1)), mu, nu);
        [LamthetaU, LamdeltastarU] = thwaites(coords(:,stagind:TrindU), Vt(stagind:TrindU), mu, nu);
        %% patch discontinuity at stagnation point
        LamthetaL(1) = (3/4)*LamthetaL(2)+(1/4)*LamthetaU(2);
        LamthetaU(1) = (3/4)*LamthetaU(2)+(1/4)*LamthetaL(2);
        LamdeltastarL(1) = (3/4)*LamdeltastarL(2)+(1/4)*LamdeltastarU(2);
        LamdeltastarU(1) = (3/4)*LamdeltastarU(2)+(1/4)*LamdeltastarL(2);
        %% patch discontinuity at transition
        theta0L = LamthetaL(end) + (LamthetaL(end)-LamthetaL(end-1));
        theta0U = LamthetaU(end) + (LamthetaU(end)-LamthetaU(end-1));
        %% 4dii:  turbulent region
        H0 = 1.3;
        [TurbthetaL, TurbdeltastarL, ~] = heads(fliplr(coords(:,1:TrindL-1)), fliplr(-Vt(1:TrindL-1)), theta0L, H0, mu, nu);
        [TurbthetaU, TurbdeltastarU, ~] = heads(coords(:,TrindU+1:end-1), Vt(TrindU+1:end), theta0U, H0, mu, nu);
        %% 4diii: combine
    theta = [fliplr([LamthetaL, TurbthetaL]), [LamthetaU, TurbthetaU]];
    deltastar = [fliplr([LamdeltastarL, TurbdeltastarL]), [LamdeltastarU, TurbdeltastarU]];
        %% 4div:  fudge TE BL to not break kutta condition B.C.
    % linear growth behind 1-Ncut chord
    
    Ncut = 0.1;
    cutind = floor(N*Ncut);
    
    dthetadx = diff(theta)./diff(coords(1,[1:stagind-1, stagind+1:end]));
    ddeltastardx = diff(deltastar)./diff(coords(1,[1:stagind-1, stagind+1:end]));
    dx = diff(coords(1,[1:stagind-1, stagind+1:end]));
    
    % lower surface
    deltastar(1:cutind) = ones(1,cutind).*deltastar(cutind) + ddeltastardx(cutind).*fliplr(cumsum([dx(1:cutind-1), 0]));
    thetastar(1:cutind) = ones(1,cutind).*theta(cutind) + dthetadx(cutind).*fliplr(cumsum([dx(1:cutind-1), 0]));
    
    
    % upper surface
    deltastar(end-cutind+1:end) = ones(1,cutind).*deltastar(end-cutind+1) + ddeltastardx(end-cutind+1).*cumsum([0, dx(end-cutind+2:end)]);
    thetastar(end-cutind+1:end) = ones(1,cutind).*theta(end-cutind+1) + dthetadx(end-cutind+1).*cumsum([0, dx(end-cutind+2:end)]);
    %% 4e: displace panel coordinates by delta*
    [dispCoords] = surfDisp(geoCoords, deltastar);
    %% 4f: pass displaced coordinates back to 3a, repear until converged
    coords = dispCoords;
    %% 4g: monitor progress
    %% 4h: update loop index
    iter = iter+1;
end

%% 5: calculate drag from final iteration results and geometry

ue = Vt;
dthetads = gradient(theta, S);
H = deltastar./theta;
dueds = gradient(Vt, S);

Cf = 2*(dthetads + (2+H).*(theta./ue) .*dueds);

Cpv = Cp;

end

