function [X, Y, U, V] = Vfield(coords, limits, q, g, Vinf, alpha)
%Vfield creates a global velocity field, useful for visualization
%   Detailed explanation goes here

%% plotting points

Xu = linspace(limits(1,1), limits(1,2), 100);
Yv = linspace(limits(2,1), limits(2,2), 100);

%% geometry discretization
% surface panel edges
X = coords(1,:);
Y = coords(2,:);

N = length(X)-1;

% panel lengths
l = sqrt(diff(X).^2 + diff(Y).^2);

% panel global angle
theta = atan2(diff(Y), diff(X));


end
