function [Vt] = panel2Vt(coords, q, g, Vinf, alpha)
%panel2Vt Calculates surface tangential velocity
%   Detailed explanation goes here

%% geometry discretization
% surface panel edges
X = coords(1,:);
Y = coords(2,:);

N = length(X)-1;

% control points
Xc = X(1:N) + diff(X)/2;
Yc = Y(1:N) + diff(Y)/2;

% panel lengths
l = sqrt(diff(X).^2 + diff(Y).^2);
sth = diff(Y)./l;
cth = diff(X)./l;

% normal and tangential vectors
n = [-sth; cth];
t = [cth; sth];

% panel global angle
theta = atan2(diff(Y), diff(X));

%% tangential velocity
for i = 1:N
    Vtf(i) = Vinf*cos(theta(i) - alpha);
    for j = 1:N
        Vtq(i,j) = q(j)/(2*pi) * (sin(theta(i)-theta(j))*beta(i,j) ...
            - cos(theta(i)-theta(j))*log(r(i,j+1)/r(i,j)));
        Vtg(i,j) = g/(2*pi) * (sin(theta(i)-theta(j))*log(r(i,j+1)/r(i,j)) ...
            + cos(theta(i)-theta(j))*beta(i,j));
    end
    Vt(i) = Vtf(i) + sum(Vtq(i,:)) + sum(Vtg(i,:));
end



end

